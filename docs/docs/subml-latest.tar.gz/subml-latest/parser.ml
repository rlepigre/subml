[@@@ocaml.text
  "{3                           You guessed it                             }"]
open Earley
open Bindlib
open Ast
open Pos
open Print
open Eval
open TypingBase
open Typing
open Raw
open Format
open LibTools
exception Unclosed of bool * popt 
let unclosed_comment in_string (buf,pos) =
  let p = Pos.locate buf pos buf (pos + (if in_string then 1 else 2))  in
  raise (Unclosed (in_string, (Some p))) 
let subml_blank buf pos =
  let rec fn state stack prev curr =
    let (buf,pos) = curr  in
    let (c,buf',pos') = Input.read buf pos  in
    let next = (buf', pos')  in
    match (state, stack, c) with
    | (`Ini,[],' ')|(`Ini,[],'\t')|(`Ini,[],'\r')|(`Ini,[],'\n') ->
        fn `Ini stack curr next
    | (`Ini,_,'(') -> fn (`Opn curr) stack curr next
    | (`Ini,[],_) -> curr
    | (`Opn p,_,'*') -> fn `Ini (p :: stack) curr next
    | (`Opn _,_::_,'"') -> fn (`Str curr) stack curr next
    | (`Opn _,[],_) -> prev
    | (`Opn _,_,_) -> fn `Ini stack curr next
    | (`Ini,_::_,'"') -> fn (`Str curr) stack curr next
    | (`Str _,_::_,'"') -> fn `Ini stack curr next
    | (`Str p,_::_,'\\') -> fn (`Esc p) stack curr next
    | (`Esc p,_::_,_) -> fn (`Str p) stack curr next
    | (`Str p,_::_,'\255') -> unclosed_comment true p
    | (`Str _,_::_,_) -> fn state stack curr next
    | (`Str _,[],_) -> assert false
    | (`Esc _,[],_) -> assert false
    | (`Ini,_::_,'*') -> fn `Cls stack curr next
    | (`Cls,_::_,'*') -> fn `Cls stack curr next
    | (`Cls,_::s,')') -> fn `Ini s curr next
    | (`Cls,_::_,_) -> fn `Ini stack curr next
    | (`Cls,[],_) -> assert false
    | (`Ini,p::_,'\255') -> unclosed_comment false p
    | (`Ini,_::_,_) -> fn `Ini stack curr next  in
  fn `Ini [] (buf, pos) (buf, pos) 
let keywords = Hashtbl.create 20 
let is_keyword = (Hashtbl.mem keywords : string -> bool) 
let check_not_keyword =
  (fun s  -> if is_keyword s then give_up () : string -> unit) 
let new_keyword =
  (fun s  ->
     let ls = String.length s  in
     if ls < 1 then raise (Invalid_argument "invalid keyword");
     if is_keyword s then raise (Invalid_argument "keyword already defied");
     Hashtbl.add keywords s s;
     (let f str pos =
        let str = ref str  in
        let pos = ref pos  in
        for i = 0 to ls - 1 do
          (let (c,str',pos') = Input.read (!str) (!pos)  in
           if c <> (s.[i]) then give_up (); str := str'; pos := pos')
        done;
        (let (c,_,_) = Input.read (!str) (!pos)  in
         match c with
         | 'a'..'z'|'A'..'Z'|'0'..'9'|'_'|'\'' -> give_up ()
         | _ -> ((), (!str), (!pos)))
         in
      black_box f (Charset.singleton (s.[0])) false s) : string ->
                                                           unit grammar)
  
let glist_sep elt sep =
  Earley.alternatives
    [Earley.sequence elt
       (Earley.apply List.rev
          (Earley.fixpoint []
             (Earley.apply (fun x  -> fun y  -> x :: y)
                (Earley.sequence sep elt (fun _  -> fun e  -> e)))))
       (fun e  -> fun es  -> e :: es);
    Earley.apply (fun _  -> []) (Earley.empty ())]
  
let glist_sep' elt sep =
  Earley.sequence elt
    (Earley.apply List.rev
       (Earley.fixpoint []
          (Earley.apply (fun x  -> fun y  -> x :: y)
             (Earley.sequence sep elt (fun _  -> fun e  -> e)))))
    (fun e  -> fun es  -> e :: es)
  
let glist_sep'' elt sep =
  Earley.sequence elt
    (Earley.apply List.rev
       (Earley.fixpoint1 []
          (Earley.apply (fun x  -> fun y  -> x :: y)
             (Earley.sequence sep elt (fun _  -> fun e  -> e)))))
    (fun e  -> fun es  -> e :: es)
  
let list_sep elt sep = glist_sep elt (string sep ()) 
let list_sep' elt sep = glist_sep' elt (string sep ()) 
let list_sep'' elt sep = glist_sep'' elt (string sep ()) 
let str_lit =
  let normal =
    in_charset (List.fold_left Charset.del Charset.full ['\\'; '"'; '\r'])
     in
  let schar =
    Earley.alternatives
      [Earley.apply (fun c  -> String.make 1 c) normal;
      Earley.apply (fun _  -> "\"") (Earley.string "\\\"" "\\\"");
      Earley.apply (fun _  -> "\\") (Earley.string "\\\\" "\\\\");
      Earley.apply (fun _  -> "\n") (Earley.string "\\n" "\\n");
      Earley.apply (fun _  -> "\t") (Earley.string "\\t" "\\t")]
     in
  change_layout
    (Earley.fsequence (Earley.string "\"" "\"")
       (Earley.sequence
          (Earley.apply List.rev
             (Earley.fixpoint []
                (Earley.apply (fun x  -> fun y  -> x :: y) schar)))
          (Earley.string "\"" "\"")
          (fun cs  -> fun _  -> fun _  -> String.concat "" cs))) no_blank
  
let int_lit = Earley.declare_grammar "int_lit" 
let _ =
  Earley.set_grammar int_lit
    (Earley.apply (fun i  -> int_of_string (i.(0)))
       (Earley.regexp ~name:"[-]?[0-9]+" "\\([-]?[0-9]+\\)"))
  
let lident = Earley.declare_grammar "lident" 
let _ =
  Earley.set_grammar lident
    (Earley.apply
       (fun id  -> if id = "_" then give_up (); check_not_keyword id; id)
       (Earley.apply (fun group  -> group.(0))
          (Earley.regexp ~name:"[_a-z0-9][_a-zA-Z0-9]*[']*"
             "\\([_a-z0-9][_a-zA-Z0-9]*[']*\\)")))
  
let uident = Earley.declare_grammar "uident" 
let _ =
  Earley.set_grammar uident
    (Earley.apply (fun id  -> check_not_keyword id; id)
       (Earley.apply (fun group  -> group.(0))
          (Earley.regexp ~name:"[A-Z][_a-zA-Z0-9]*[']*"
             "\\([A-Z][_a-zA-Z0-9]*[']*\\)")))
  
let loptident = Earley.declare_grammar "loptident" 
let _ =
  Earley.set_grammar loptident
    (Earley.alternatives
       [Earley.apply (fun _  -> "") (Earley.string "_" "_"); lident])
  
let llident = Earley.declare_grammar "llident" 
let _ =
  Earley.set_grammar llident
    (Earley.apply_position
       (fun id  ->
          fun __loc__start__buf  ->
            fun __loc__start__pos  ->
              fun __loc__end__buf  ->
                fun __loc__end__pos  ->
                  let _loc =
                    locate __loc__start__buf __loc__start__pos
                      __loc__end__buf __loc__end__pos
                     in
                  in_pos _loc id) lident)
  
let greek = Earley.declare_grammar "greek" 
let _ =
  Earley.set_grammar greek
    (Earley.alternatives
       [Earley.apply (fun _  -> "\206\180")
          (Earley.string "\206\180" "\206\180");
       Earley.apply (fun _  -> "\206\177")
         (Earley.string "\206\177" "\206\177");
       Earley.apply (fun _  -> "\206\178")
         (Earley.string "\206\178" "\206\178");
       Earley.apply (fun _  -> "\206\179")
         (Earley.string "\206\179" "\206\179")])
  
let lgident = Earley.declare_grammar "lgident" 
let _ =
  Earley.set_grammar lgident
    (Earley.sequence greek
       (Earley.option ""
          (Earley.apply (fun group  -> group.(0))
             (Earley.regexp ~name:"[_][0-9]+" "\\([_][0-9]+\\)")))
       (fun g  -> fun l  -> g ^ l))
  
let build_prod l =
  List.mapi (fun i  -> fun x  -> ((string_of_int (i + 1)), x)) l 
let case_kw = new_keyword "case" 
let rec_kw = new_keyword "rec" 
let let_kw = new_keyword "let" 
let such_kw = new_keyword "such" 
let that_kw = new_keyword "that" 
let val_kw = new_keyword "val" 
let of_kw = new_keyword "of" 
let in_kw = new_keyword "in" 
let fix_kw = new_keyword "fix" 
let fun_kw = new_keyword "fun" 
let if_kw = new_keyword "if" 
let then_kw = new_keyword "then" 
let else_kw = new_keyword "else" 
let with_kw = new_keyword "with" 
let type_kw = new_keyword "type" 
let abrt_kw = new_keyword "abort" 
let unfold_kw = new_keyword "unfold" 
let clear_kw = new_keyword "clear" 
let parse_kw = new_keyword "parse" 
let quit_kw = new_keyword "quit" 
let exit_kw = new_keyword "exit" 
let eval_kw = new_keyword "eval" 
let set_kw = new_keyword "set" 
let include_kw = new_keyword "include" 
let check_kw = new_keyword "check" 
let latex_kw = new_keyword "latex" 
let graphml_kw = new_keyword "graphml" 
let arrow = Earley.declare_grammar "arrow" 
let _ =
  Earley.set_grammar arrow
    (Earley.alternatives
       [Earley.apply (fun _  -> ()) (Earley.string "->" "->");
       Earley.apply (fun _  -> ())
         (Earley.string "\226\134\146" "\226\134\146")] : unit grammar)
  
let forall = Earley.declare_grammar "forall" 
let _ =
  Earley.set_grammar forall
    (Earley.alternatives
       [Earley.apply (fun _  -> ()) (Earley.string "/\\" "/\\");
       Earley.apply (fun _  -> ())
         (Earley.string "\226\136\128" "\226\136\128")] : unit grammar)
  
let exists = Earley.declare_grammar "exists" 
let _ =
  Earley.set_grammar exists
    (Earley.alternatives
       [Earley.apply (fun _  -> ()) (Earley.string "\\/" "\\/");
       Earley.apply (fun _  -> ())
         (Earley.string "\226\136\131" "\226\136\131")] : unit grammar)
  
let mu = Earley.declare_grammar "mu" 
let _ =
  Earley.set_grammar mu
    (Earley.alternatives
       [Earley.apply (fun _  -> ()) (Earley.string "!" "!");
       Earley.apply (fun _  -> ()) (Earley.string "\206\188" "\206\188")] : 
    unit grammar)
  
let nu = Earley.declare_grammar "nu" 
let _ =
  Earley.set_grammar nu
    (Earley.alternatives
       [Earley.apply (fun _  -> ()) (Earley.string "?" "?");
       Earley.apply (fun _  -> ()) (Earley.string "\206\189" "\206\189")] : 
    unit grammar)
  
let time = Earley.declare_grammar "time" 
let _ =
  Earley.set_grammar time
    (Earley.alternatives
       [Earley.apply (fun _  -> ()) (Earley.string "*" "*");
       Earley.apply (fun _  -> ()) (Earley.string "\195\151" "\195\151")] : 
    unit grammar)
  
let lambda = Earley.declare_grammar "lambda" 
let _ =
  Earley.set_grammar lambda
    (Earley.apply (fun _  -> ()) (Earley.string "\206\187" "\206\187") : 
    unit grammar)
  
let dot = Earley.declare_grammar "dot" 
let _ =
  Earley.set_grammar dot
    (Earley.apply (fun _  -> ()) (Earley.string "." ".") : unit grammar)
  
let comma = Earley.declare_grammar "comma" 
let _ =
  Earley.set_grammar comma
    (Earley.apply (fun _  -> ()) (Earley.string "," ",") : unit grammar)
  
let subset = Earley.declare_grammar "subset" 
let _ =
  Earley.set_grammar subset
    (Earley.alternatives
       [Earley.apply (fun _  -> ()) (Earley.string "<" "<");
       Earley.apply (fun _  -> ())
         (Earley.string "\226\138\130" "\226\138\130");
       Earley.apply (fun _  -> ())
         (Earley.string "\226\138\134" "\226\138\134")] : unit grammar)
  
let infty = Earley.declare_grammar "infty" 
let _ =
  Earley.set_grammar infty
    (Earley.apply (fun _  -> ())
       (Earley.string "\226\136\158" "\226\136\158") : unit grammar)
  
let eps = Earley.declare_grammar "eps" 
let _ =
  Earley.set_grammar eps
    (Earley.apply (fun _  -> ()) (Earley.string "\206\181" "\206\181") : 
    unit grammar)
  
let kuvar = Earley.declare_grammar "kuvar" 
let _ =
  Earley.set_grammar kuvar
    (Earley.apply (fun _  -> ()) (Earley.string "?" "?") : unit grammar)
  
let ouvar = Earley.declare_grammar "ouvar" 
let _ =
  Earley.set_grammar ouvar
    (Earley.apply (fun _  -> ()) (Earley.string "\194\191" "\194\191") : 
    unit grammar)
  
let mem = Earley.declare_grammar "mem" 
let _ =
  Earley.set_grammar mem
    (Earley.alternatives
       [Earley.apply (fun _  -> false)
          (Earley.string "\226\136\137" "\226\136\137");
       Earley.apply (fun _  -> true)
         (Earley.string "\226\136\136" "\226\136\136")] : bool grammar)
  
let is_rec = Earley.declare_grammar "is_rec" 
let _ =
  Earley.set_grammar is_rec
    (Earley.alternatives
       [Earley.apply (fun _default_0  -> true) rec_kw;
       Earley.apply (fun _  -> false) (Earley.empty ())])
  
let enables = Earley.declare_grammar "enables" 
let _ =
  Earley.set_grammar enables
    (Earley.alternatives
       [Earley.apply (fun _  -> false) (Earley.string "off" "off");
       Earley.apply (fun _  -> true) (Earley.string "on" "on")])
  
let ordi = Earley.declare_grammar "ordi" 
let _ =
  Earley.set_grammar ordi
    (Earley.alternatives
       [Earley.apply_position
          (fun _default_0  ->
             fun __loc__start__buf  ->
               fun __loc__start__pos  ->
                 fun __loc__end__buf  ->
                   fun __loc__end__pos  ->
                     let _loc =
                       locate __loc__start__buf __loc__start__pos
                         __loc__end__buf __loc__end__pos
                        in
                     in_pos _loc POVar) ouvar;
       Earley.apply_position
         (fun _default_0  ->
            fun __loc__start__buf  ->
              fun __loc__start__pos  ->
                fun __loc__end__buf  ->
                  fun __loc__end__pos  ->
                    let _loc =
                      locate __loc__start__buf __loc__start__pos
                        __loc__end__buf __loc__end__pos
                       in
                    in_pos _loc PConv)
         (Earley.option None (Earley.apply (fun x  -> Some x) infty));
       Earley.apply_position
         (fun s  ->
            fun __loc__start__buf  ->
              fun __loc__start__pos  ->
                fun __loc__end__buf  ->
                  fun __loc__end__pos  ->
                    let _loc =
                      locate __loc__start__buf __loc__start__pos
                        __loc__end__buf __loc__end__pos
                       in
                    in_pos _loc (PVari s)) lgident;
       Earley.fsequence_position ordi
         (Earley.sequence (Earley.char '+' '+') int_lit
            (fun _  ->
               fun n  ->
                 fun o  ->
                   fun __loc__start__buf  ->
                     fun __loc__start__pos  ->
                       fun __loc__end__buf  ->
                         fun __loc__end__pos  ->
                           let _loc =
                             locate __loc__start__buf __loc__start__pos
                               __loc__end__buf __loc__end__pos
                              in
                           padd _loc o n))])
  
let kind = Earley.declare_grammar "kind" 
let kind_atm = Earley.declare_grammar "kind_atm" 
let kind_prd = Earley.declare_grammar "kind_prd" 
let ext = Earley.declare_grammar "ext" 
let (pkind,pkind__set__grammar) = Earley.grammar_family "pkind" 
let epsilon = Earley.declare_grammar "epsilon" 
let kind_args = Earley.declare_grammar "kind_args" 
let kind_prod = Earley.declare_grammar "kind_prod" 
let kind_dsum = Earley.declare_grammar "kind_dsum" 
let kind_reco = Earley.declare_grammar "kind_reco" 
let with_eq = Earley.declare_grammar "with_eq" 
let term = Earley.declare_grammar "term" 
let tapp = Earley.declare_grammar "tapp" 
let tseq = Earley.declare_grammar "tseq" 
let tcol = Earley.declare_grammar "tcol" 
let tatm = Earley.declare_grammar "tatm" 
let (pterm,pterm__set__grammar) = Earley.grammar_family "pterm" 
let var = Earley.declare_grammar "var" 
let let_var = Earley.declare_grammar "let_var" 
let term_llet = Earley.declare_grammar "term_llet" 
let ords_kinds = Earley.declare_grammar "ords_kinds" 
let term_mlet = Earley.declare_grammar "term_mlet" 
let term_cond = Earley.declare_grammar "term_cond" 
let term_reco = Earley.declare_grammar "term_reco" 
let term_prod = Earley.declare_grammar "term_prod" 
let field = Earley.declare_grammar "field" 
let term_list = Earley.declare_grammar "term_list" 
let pats = Earley.declare_grammar "pats" 
let fpat = Earley.declare_grammar "fpat" 
let rpat = Earley.declare_grammar "rpat" 
let pattern = Earley.declare_grammar "pattern" 
let case = Earley.declare_grammar "case" 
let default = Earley.declare_grammar "default" 
let _ = Earley.set_grammar kind (pkind `Fun : pkind grammar) 
let _ = Earley.set_grammar kind_atm (pkind `Atm) 
let _ = Earley.set_grammar kind_prd (pkind `Prd) 
let _ =
  Earley.set_grammar ext
    (Earley.alternatives
       [Earley.sequence (Earley.char ';' ';')
          (Earley.alternatives
             [Earley.apply (fun _  -> ())
                (Earley.string "\226\128\166" "\226\128\166");
             Earley.apply (fun _  -> ()) (Earley.string "..." "...")])
          (fun _  -> fun _default_0  -> true);
       Earley.apply (fun _  -> false) (Earley.empty ())])
  
let _ =
  pkind__set__grammar
    (fun (p : [ `Atm  | `Prd  | `Fun ])  ->
       Earley.alternatives
         ((if p = `Atm
           then
             [Earley.apply_position
                (fun _default_0  ->
                   fun __loc__start__buf  ->
                     fun __loc__start__pos  ->
                       fun __loc__end__buf  ->
                         fun __loc__end__pos  ->
                           let _loc =
                             locate __loc__start__buf __loc__start__pos
                               __loc__end__buf __loc__end__pos
                              in
                           in_pos _loc PUVar) kuvar]
           else []) @
            ((if p = `Fun
              then
                [Earley.fsequence_position kind_prd
                   (Earley.sequence arrow kind
                      (fun _default_0  ->
                         fun b  ->
                           fun a  ->
                             fun __loc__start__buf  ->
                               fun __loc__start__pos  ->
                                 fun __loc__end__buf  ->
                                   fun __loc__end__pos  ->
                                     let _loc =
                                       locate __loc__start__buf
                                         __loc__start__pos __loc__end__buf
                                         __loc__end__pos
                                        in
                                     in_pos _loc (PFunc (a, b))))]
              else []) @
               ((if p = `Atm
                 then
                   [Earley.sequence_position uident (Earley.greedy kind_args)
                      (fun id  ->
                         fun ((o,k) as _default_0)  ->
                           fun __loc__start__buf  ->
                             fun __loc__start__pos  ->
                               fun __loc__end__buf  ->
                                 fun __loc__end__pos  ->
                                   let _loc =
                                     locate __loc__start__buf
                                       __loc__start__pos __loc__end__buf
                                       __loc__end__pos
                                      in
                                   in_pos _loc (PTVar (id, o, k)))]
                 else []) @
                  ((if p = `Fun
                    then
                      [Earley.fsequence_position forall
                         (Earley.sequence uident kind
                            (fun id  ->
                               fun a  ->
                                 fun _default_0  ->
                                   fun __loc__start__buf  ->
                                     fun __loc__start__pos  ->
                                       fun __loc__end__buf  ->
                                         fun __loc__end__pos  ->
                                           let _loc =
                                             locate __loc__start__buf
                                               __loc__start__pos
                                               __loc__end__buf
                                               __loc__end__pos
                                              in
                                           in_pos _loc (PKAll (id, a))))]
                    else []) @
                     ((if p = `Fun
                       then
                         [Earley.fsequence_position exists
                            (Earley.sequence uident kind
                               (fun id  ->
                                  fun a  ->
                                    fun _default_0  ->
                                      fun __loc__start__buf  ->
                                        fun __loc__start__pos  ->
                                          fun __loc__end__buf  ->
                                            fun __loc__end__pos  ->
                                              let _loc =
                                                locate __loc__start__buf
                                                  __loc__start__pos
                                                  __loc__end__buf
                                                  __loc__end__pos
                                                 in
                                              in_pos _loc (PKExi (id, a))))]
                       else []) @
                        ((if p = `Fun
                          then
                            [Earley.fsequence_position forall
                               (Earley.sequence lgident kind
                                  (fun id  ->
                                     fun a  ->
                                       fun _default_0  ->
                                         fun __loc__start__buf  ->
                                           fun __loc__start__pos  ->
                                             fun __loc__end__buf  ->
                                               fun __loc__end__pos  ->
                                                 let _loc =
                                                   locate __loc__start__buf
                                                     __loc__start__pos
                                                     __loc__end__buf
                                                     __loc__end__pos
                                                    in
                                                 in_pos _loc (POAll (id, a))))]
                          else []) @
                           ((if p = `Fun
                             then
                               [Earley.fsequence_position exists
                                  (Earley.sequence lgident kind
                                     (fun id  ->
                                        fun a  ->
                                          fun _default_0  ->
                                            fun __loc__start__buf  ->
                                              fun __loc__start__pos  ->
                                                fun __loc__end__buf  ->
                                                  fun __loc__end__pos  ->
                                                    let _loc =
                                                      locate
                                                        __loc__start__buf
                                                        __loc__start__pos
                                                        __loc__end__buf
                                                        __loc__end__pos
                                                       in
                                                    in_pos _loc
                                                      (POExi (id, a))))]
                             else []) @
                              ((if p = `Fun
                                then
                                  [Earley.fsequence_position mu
                                     (Earley.fsequence ordi
                                        (Earley.sequence uident kind
                                           (fun id  ->
                                              fun a  ->
                                                fun o  ->
                                                  fun _default_0  ->
                                                    fun __loc__start__buf  ->
                                                      fun __loc__start__pos 
                                                        ->
                                                        fun __loc__end__buf 
                                                          ->
                                                          fun __loc__end__pos
                                                             ->
                                                            let _loc =
                                                              locate
                                                                __loc__start__buf
                                                                __loc__start__pos
                                                                __loc__end__buf
                                                                __loc__end__pos
                                                               in
                                                            in_pos _loc
                                                              (PFixM
                                                                 (o, id, a)))))]
                                else []) @
                                 ((if p = `Fun
                                   then
                                     [Earley.fsequence_position nu
                                        (Earley.fsequence ordi
                                           (Earley.sequence uident kind
                                              (fun id  ->
                                                 fun a  ->
                                                   fun o  ->
                                                     fun _default_0  ->
                                                       fun __loc__start__buf 
                                                         ->
                                                         fun
                                                           __loc__start__pos 
                                                           ->
                                                           fun
                                                             __loc__end__buf 
                                                             ->
                                                             fun
                                                               __loc__end__pos
                                                                ->
                                                               let _loc =
                                                                 locate
                                                                   __loc__start__buf
                                                                   __loc__start__pos
                                                                   __loc__end__buf
                                                                   __loc__end__pos
                                                                  in
                                                               in_pos _loc
                                                                 (PFixN
                                                                    (o, id,
                                                                    a)))))]
                                   else []) @
                                    ((if p = `Atm
                                      then
                                        [Earley.fsequence_position
                                           (Earley.string "{" "{")
                                           (Earley.fsequence kind_reco
                                              (Earley.sequence ext
                                                 (Earley.string "}" "}")
                                                 (fun e  ->
                                                    fun _  ->
                                                      fun fs  ->
                                                        fun _  ->
                                                          fun
                                                            __loc__start__buf
                                                             ->
                                                            fun
                                                              __loc__start__pos
                                                               ->
                                                              fun
                                                                __loc__end__buf
                                                                 ->
                                                                fun
                                                                  __loc__end__pos
                                                                   ->
                                                                  let _loc =
                                                                    locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                     in
                                                                  in_pos _loc
                                                                    (
                                                                    PProd
                                                                    (fs, e)))))]
                                      else []) @
                                       ((if p = `Prd
                                         then
                                           [Earley.apply_position
                                              (fun fs  ->
                                                 fun __loc__start__buf  ->
                                                   fun __loc__start__pos  ->
                                                     fun __loc__end__buf  ->
                                                       fun __loc__end__pos 
                                                         ->
                                                         let _loc =
                                                           locate
                                                             __loc__start__buf
                                                             __loc__start__pos
                                                             __loc__end__buf
                                                             __loc__end__pos
                                                            in
                                                         in_pos _loc
                                                           (PProd (fs, false)))
                                              kind_prod]
                                         else []) @
                                          ((if p = `Atm
                                            then
                                              [Earley.fsequence_position
                                                 (Earley.string "[" "[")
                                                 (Earley.sequence kind_dsum
                                                    (Earley.string "]" "]")
                                                    (fun fs  ->
                                                       fun _  ->
                                                         fun _  ->
                                                           fun
                                                             __loc__start__buf
                                                              ->
                                                             fun
                                                               __loc__start__pos
                                                                ->
                                                               fun
                                                                 __loc__end__buf
                                                                  ->
                                                                 fun
                                                                   __loc__end__pos
                                                                    ->
                                                                   let _loc =
                                                                    locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                     in
                                                                   in_pos
                                                                    _loc
                                                                    (PDSum fs)))]
                                            else []) @
                                             ((if p = `Atm
                                               then
                                                 [Earley.sequence_position
                                                    kind_atm with_eq
                                                    (fun a  ->
                                                       fun
                                                         ((s,b) as _default_0)
                                                          ->
                                                         fun
                                                           __loc__start__buf 
                                                           ->
                                                           fun
                                                             __loc__start__pos
                                                              ->
                                                             fun
                                                               __loc__end__buf
                                                                ->
                                                               fun
                                                                 __loc__end__pos
                                                                  ->
                                                                 let _loc =
                                                                   locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                    in
                                                                 in_pos _loc
                                                                   (PWith
                                                                    (a, s, b)))]
                                               else []) @
                                                ((if p = `Atm
                                                  then
                                                    [Earley.fsequence_position
                                                       llident
                                                       (Earley.sequence
                                                          (Earley.char '.'
                                                             '.') uident
                                                          (fun _  ->
                                                             fun s  ->
                                                               fun id  ->
                                                                 fun
                                                                   __loc__start__buf
                                                                    ->
                                                                   fun
                                                                    __loc__start__pos
                                                                     ->
                                                                    fun
                                                                    __loc__end__buf
                                                                     ->
                                                                    fun
                                                                    __loc__end__pos
                                                                     ->
                                                                    let _loc
                                                                    =
                                                                    locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                     in
                                                                    in_pos
                                                                    _loc
                                                                    (PDPrj
                                                                    (id, s))))]
                                                  else []) @
                                                   ((if p = `Atm
                                                     then
                                                       [Earley.fsequence
                                                          (Earley.string "("
                                                             "(")
                                                          (Earley.sequence
                                                             kind
                                                             (Earley.string
                                                                ")" ")")
                                                             (fun _default_0 
                                                                ->
                                                                fun _  ->
                                                                  fun _  ->
                                                                    _default_0))]
                                                     else []) @
                                                      ((if p = `Prd
                                                        then [kind_atm]
                                                        else []) @
                                                         ((if p = `Fun
                                                           then [kind_prd]
                                                           else []) @
                                                            ((if p = `Atm
                                                              then
                                                                [Earley.sequence_position
                                                                   eps
                                                                   epsilon
                                                                   (fun
                                                                    _default_0
                                                                     ->
                                                                    fun w  ->
                                                                    fun
                                                                    __loc__start__buf
                                                                     ->
                                                                    fun
                                                                    __loc__start__pos
                                                                     ->
                                                                    fun
                                                                    __loc__end__buf
                                                                     ->
                                                                    fun
                                                                    __loc__end__pos
                                                                     ->
                                                                    let _loc
                                                                    =
                                                                    locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                     in
                                                                    in_pos
                                                                    _loc w)]
                                                              else []) @ [])))))))))))))))))))
  
let _ =
  Earley.set_grammar epsilon
    (Earley.fsequence uident
       (Earley.fsequence (Earley.char '(' '(')
          (Earley.fsequence term
             (Earley.fsequence mem
                (Earley.sequence kind (Earley.char ')' ')')
                   (fun a  ->
                      fun _  ->
                        fun m  ->
                          fun t  ->
                            fun _  ->
                              fun id  ->
                                if m
                                then PECst (t, id, a)
                                else PUCst (t, id, a)))))))
  
let _ =
  Earley.set_grammar kind_args
    (Earley.alternatives
       [Earley.fsequence (Earley.string "(" "(")
          (Earley.fsequence (list_sep' ordi ",")
             (Earley.sequence
                (Earley.option []
                   (Earley.sequence (Earley.string "," ",")
                      (list_sep kind ",") (fun _  -> fun ks  -> ks)))
                (Earley.string ")" ")")
                (fun ks  -> fun _  -> fun os  -> fun _  -> (os, ks))));
       Earley.apply (fun _  -> ([], [])) (Earley.empty ());
       Earley.fsequence (Earley.string "(" "(")
         (Earley.sequence (list_sep' kind ",") (Earley.string ")" ")")
            (fun ks  -> fun _  -> fun _  -> ([], ks)))])
  
let _ =
  Earley.set_grammar kind_prod
    (Earley.apply (fun fs  -> build_prod fs) (glist_sep'' kind_atm time))
  
let _ =
  Earley.set_grammar kind_dsum
    (list_sep
       (Earley.sequence uident
          (Earley.option None
             (Earley.apply (fun x  -> Some x)
                (Earley.sequence of_kw kind
                   (fun _  -> fun _default_0  -> _default_0))))
          (fun _default_0  -> fun a  -> (_default_0, a))) "|")
  
let _ =
  Earley.set_grammar kind_reco
    (list_sep
       (Earley.fsequence lident
          (Earley.sequence (Earley.string ":" ":") kind
             (fun _  ->
                fun _default_0  ->
                  fun _default_1  -> (_default_1, _default_0)))) ";")
  
let _ =
  Earley.set_grammar with_eq
    (Earley.fsequence with_kw
       (Earley.fsequence uident
          (Earley.sequence (Earley.string "=" "=") kind_atm
             (fun _  -> fun b  -> fun s  -> fun _  -> (s, b)))))
  
let _ = Earley.set_grammar term (pterm `Lam : pterm grammar) 
let _ = Earley.set_grammar tapp (pterm `App) 
let _ = Earley.set_grammar tseq (pterm `Seq) 
let _ = Earley.set_grammar tcol (pterm `Col) 
let _ = Earley.set_grammar tatm (pterm `Atm) 
let _ =
  pterm__set__grammar
    (fun (p : [ `Lam  | `Seq  | `App  | `Col  | `Atm ])  ->
       Earley.alternatives
         ((if p = `App then [tcol] else []) @
            ((if p = `Lam
              then
                [Earley.fsequence_position lambda
                   (Earley.fsequence
                      (Earley.apply List.rev
                         (Earley.fixpoint1 []
                            (Earley.apply (fun x  -> fun y  -> x :: y) fpat)))
                      (Earley.sequence dot (Earley.greedy term)
                         (fun _default_0  ->
                            fun t  ->
                              fun xs  ->
                                fun _default_1  ->
                                  fun __loc__start__buf  ->
                                    fun __loc__start__pos  ->
                                      fun __loc__end__buf  ->
                                        fun __loc__end__pos  ->
                                          let _loc =
                                            locate __loc__start__buf
                                              __loc__start__pos
                                              __loc__end__buf __loc__end__pos
                                             in
                                          plabs _loc xs t)))]
              else []) @
               ((if p = `Lam
                 then
                   [Earley.fsequence_position fun_kw
                      (Earley.fsequence
                         (Earley.apply List.rev
                            (Earley.fixpoint1 []
                               (Earley.apply (fun x  -> fun y  -> x :: y)
                                  fpat)))
                         (Earley.sequence arrow (Earley.greedy term)
                            (fun _default_0  ->
                               fun t  ->
                                 fun xs  ->
                                   fun _default_1  ->
                                     fun __loc__start__buf  ->
                                       fun __loc__start__pos  ->
                                         fun __loc__end__buf  ->
                                           fun __loc__end__pos  ->
                                             let _loc =
                                               locate __loc__start__buf
                                                 __loc__start__pos
                                                 __loc__end__buf
                                                 __loc__end__pos
                                                in
                                             plabs _loc xs t)))]
                 else []) @
                  ((if p = `App
                    then
                      [Earley.sequence_position tapp tcol
                         (fun t  ->
                            fun u  ->
                              fun __loc__start__buf  ->
                                fun __loc__start__pos  ->
                                  fun __loc__end__buf  ->
                                    fun __loc__end__pos  ->
                                      let _loc =
                                        locate __loc__start__buf
                                          __loc__start__pos __loc__end__buf
                                          __loc__end__pos
                                         in
                                      pappl _loc t u)]
                    else []) @
                     ((if p = `Seq
                       then
                         [Earley.fsequence_position tapp
                            (Earley.sequence (Earley.string ";" ";") tseq
                               (fun _  ->
                                  fun u  ->
                                    fun t  ->
                                      fun __loc__start__buf  ->
                                        fun __loc__start__pos  ->
                                          fun __loc__end__buf  ->
                                            fun __loc__end__pos  ->
                                              let _loc =
                                                locate __loc__start__buf
                                                  __loc__start__pos
                                                  __loc__end__buf
                                                  __loc__end__pos
                                                 in
                                              sequence _loc t u))]
                       else []) @
                        ((if p = `Atm
                          then
                            [Earley.fsequence_position
                               (Earley.string "print(" "print(")
                               (Earley.fsequence (Earley.no_blank_test ())
                                  (Earley.fsequence str_lit
                                     (Earley.sequence
                                        (Earley.no_blank_test ())
                                        (Earley.string ")" ")")
                                        (fun _  ->
                                           fun _  ->
                                             fun s  ->
                                               fun _  ->
                                                 fun _  ->
                                                   fun __loc__start__buf  ->
                                                     fun __loc__start__pos 
                                                       ->
                                                       fun __loc__end__buf 
                                                         ->
                                                         fun __loc__end__pos 
                                                           ->
                                                           let _loc =
                                                             locate
                                                               __loc__start__buf
                                                               __loc__start__pos
                                                               __loc__end__buf
                                                               __loc__end__pos
                                                              in
                                                           in_pos _loc
                                                             (PPrnt s)))))]
                          else []) @
                           ((if p = `Atm
                             then
                               [Earley.apply_position
                                  (fun c  ->
                                     fun __loc__start__buf  ->
                                       fun __loc__start__pos  ->
                                         fun __loc__end__buf  ->
                                           fun __loc__end__pos  ->
                                             let _loc =
                                               locate __loc__start__buf
                                                 __loc__start__pos
                                                 __loc__end__buf
                                                 __loc__end__pos
                                                in
                                             in_pos _loc (PCons (c, None)))
                                  uident]
                             else []) @
                              ((if p = `Atm
                                then
                                  [Earley.fsequence_position tatm
                                     (Earley.sequence (Earley.string "." ".")
                                        lident
                                        (fun _  ->
                                           fun l  ->
                                             fun t  ->
                                               fun __loc__start__buf  ->
                                                 fun __loc__start__pos  ->
                                                   fun __loc__end__buf  ->
                                                     fun __loc__end__pos  ->
                                                       let _loc =
                                                         locate
                                                           __loc__start__buf
                                                           __loc__start__pos
                                                           __loc__end__buf
                                                           __loc__end__pos
                                                          in
                                                       in_pos _loc
                                                         (PProj (t, l))))]
                                else []) @
                                 ((if p = `Lam
                                   then
                                     [Earley.fsequence_position case_kw
                                        (Earley.fsequence term
                                           (Earley.fsequence of_kw
                                              (Earley.sequence pats
                                                 (Earley.greedy
                                                    (Earley.option None
                                                       (Earley.apply
                                                          (fun x  -> Some x)
                                                          default)))
                                                 (fun ps  ->
                                                    fun d  ->
                                                      fun _default_0  ->
                                                        fun t  ->
                                                          fun _default_1  ->
                                                            fun
                                                              __loc__start__buf
                                                               ->
                                                              fun
                                                                __loc__start__pos
                                                                 ->
                                                                fun
                                                                  __loc__end__buf
                                                                   ->
                                                                  fun
                                                                    __loc__end__pos
                                                                     ->
                                                                    let _loc
                                                                    =
                                                                    locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                     in
                                                                    in_pos
                                                                    _loc
                                                                    (PCase
                                                                    (t, ps,
                                                                    d))))))]
                                   else []) @
                                    ((if p = `Atm
                                      then
                                        [Earley.fsequence_position
                                           (Earley.string "{" "{")
                                           (Earley.sequence term_reco
                                              (Earley.string "}" "}")
                                              (fun fs  ->
                                                 fun _  ->
                                                   fun _  ->
                                                     fun __loc__start__buf 
                                                       ->
                                                       fun __loc__start__pos 
                                                         ->
                                                         fun __loc__end__buf 
                                                           ->
                                                           fun
                                                             __loc__end__pos 
                                                             ->
                                                             let _loc =
                                                               locate
                                                                 __loc__start__buf
                                                                 __loc__start__pos
                                                                 __loc__end__buf
                                                                 __loc__end__pos
                                                                in
                                                             in_pos _loc
                                                               (PReco fs)))]
                                      else []) @
                                       ((if p = `Atm
                                         then
                                           [Earley.fsequence_position
                                              (Earley.string "(" "(")
                                              (Earley.sequence term_prod
                                                 (Earley.string ")" ")")
                                                 (fun fs  ->
                                                    fun _  ->
                                                      fun _  ->
                                                        fun __loc__start__buf
                                                           ->
                                                          fun
                                                            __loc__start__pos
                                                             ->
                                                            fun
                                                              __loc__end__buf
                                                               ->
                                                              fun
                                                                __loc__end__pos
                                                                 ->
                                                                let _loc =
                                                                  locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                   in
                                                                in_pos _loc
                                                                  (PReco fs)))]
                                         else []) @
                                          ((if p = `Col
                                            then
                                              [Earley.fsequence_position tcol
                                                 (Earley.sequence
                                                    (Earley.string ":" ":")
                                                    (Earley.greedy kind)
                                                    (fun _  ->
                                                       fun k  ->
                                                         fun t  ->
                                                           fun
                                                             __loc__start__buf
                                                              ->
                                                             fun
                                                               __loc__start__pos
                                                                ->
                                                               fun
                                                                 __loc__end__buf
                                                                  ->
                                                                 fun
                                                                   __loc__end__pos
                                                                    ->
                                                                   let _loc =
                                                                    locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                     in
                                                                   in_pos
                                                                    _loc
                                                                    (PCoer
                                                                    (t, k))))]
                                            else []) @
                                             ((if p = `Atm
                                               then
                                                 [Earley.apply_position
                                                    (fun id  ->
                                                       fun __loc__start__buf 
                                                         ->
                                                         fun
                                                           __loc__start__pos 
                                                           ->
                                                           fun
                                                             __loc__end__buf 
                                                             ->
                                                             fun
                                                               __loc__end__pos
                                                                ->
                                                               let _loc =
                                                                 locate
                                                                   __loc__start__buf
                                                                   __loc__start__pos
                                                                   __loc__end__buf
                                                                   __loc__end__pos
                                                                  in
                                                               in_pos _loc
                                                                 (PLVar id))
                                                    lident]
                                               else []) @
                                                ((if p = `Lam
                                                  then
                                                    [Earley.fsequence fix_kw
                                                       (Earley.fsequence
                                                          (Earley.option None
                                                             (Earley.apply
                                                                (fun x  ->
                                                                   Some x)
                                                                (Earley.fsequence
                                                                   (Earley.char
                                                                    '[' '[')
                                                                   (Earley.sequence
                                                                    int_lit
                                                                    (Earley.char
                                                                    ']' ']')
                                                                    (fun n 
                                                                    ->
                                                                    fun _  ->
                                                                    fun _  ->
                                                                    n)))))
                                                          (Earley.fsequence
                                                             var
                                                             (Earley.sequence
                                                                arrow
                                                                (Earley.apply_position
                                                                   (fun x  ->
                                                                    fun str 
                                                                    ->
                                                                    fun pos 
                                                                    ->
                                                                    fun str' 
                                                                    ->
                                                                    fun pos' 
                                                                    ->
                                                                    ((locate
                                                                    str pos
                                                                    str' pos'),
                                                                    x))
                                                                   (Earley.greedy
                                                                    term))
                                                                (fun
                                                                   _default_0
                                                                    ->
                                                                   fun u  ->
                                                                    let 
                                                                    (_loc_u,u)
                                                                    = u  in
                                                                    fun x  ->
                                                                    fun n  ->
                                                                    fun
                                                                    _default_1
                                                                     ->
                                                                    pfixY x
                                                                    _loc_u n
                                                                    u))))]
                                                  else []) @
                                                   ((if p = `Atm
                                                     then
                                                       [Earley.fsequence
                                                          (Earley.string "["
                                                             "[")
                                                          (Earley.sequence
                                                             term_list
                                                             (Earley.string
                                                                "]" "]")
                                                             (fun _default_0 
                                                                ->
                                                                fun _  ->
                                                                  fun _  ->
                                                                    _default_0))]
                                                     else []) @
                                                      ((if p = `Lam
                                                        then [term_llet]
                                                        else []) @
                                                         ((if p = `Lam
                                                           then [term_mlet]
                                                           else []) @
                                                            ((if p = `Atm
                                                              then
                                                                [term_cond]
                                                              else []) @
                                                               ((if p = `Seq
                                                                 then
                                                                   [Earley.fsequence_position
                                                                    tapp
                                                                    (Earley.sequence
                                                                    (Earley.string
                                                                    "::" "::")
                                                                    (Earley.greedy
                                                                    tseq)
                                                                    (fun _ 
                                                                    ->
                                                                    fun u  ->
                                                                    fun t  ->
                                                                    fun
                                                                    __loc__start__buf
                                                                     ->
                                                                    fun
                                                                    __loc__start__pos
                                                                     ->
                                                                    fun
                                                                    __loc__end__buf
                                                                     ->
                                                                    fun
                                                                    __loc__end__pos
                                                                     ->
                                                                    let _loc
                                                                    =
                                                                    locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                     in
                                                                    list_cons
                                                                    _loc t u))]
                                                                 else []) @
                                                                  ((if
                                                                    p = `Atm
                                                                    then
                                                                    [
                                                                    Earley.apply_position
                                                                    (fun
                                                                    _default_0
                                                                     ->
                                                                    fun
                                                                    __loc__start__buf
                                                                     ->
                                                                    fun
                                                                    __loc__start__pos
                                                                     ->
                                                                    fun
                                                                    __loc__end__buf
                                                                     ->
                                                                    fun
                                                                    __loc__end__pos
                                                                     ->
                                                                    let _loc
                                                                    =
                                                                    locate
                                                                    __loc__start__buf
                                                                    __loc__start__pos
                                                                    __loc__end__buf
                                                                    __loc__end__pos
                                                                     in
                                                                    in_pos
                                                                    _loc
                                                                    PAbrt)
                                                                    abrt_kw]
                                                                    else [])
                                                                    @
                                                                    ((if
                                                                    p = `Atm
                                                                    then
                                                                    [
                                                                    Earley.fsequence
                                                                    (Earley.string
                                                                    "(" "(")
                                                                    (Earley.sequence
                                                                    term
                                                                    (Earley.string
                                                                    ")" ")")
                                                                    (fun
                                                                    _default_0
                                                                     ->
                                                                    fun _  ->
                                                                    fun _  ->
                                                                    _default_0))]
                                                                    else [])
                                                                    @
                                                                    ((if
                                                                    p = `Seq
                                                                    then
                                                                    [tapp]
                                                                    else [])
                                                                    @
                                                                    ((if
                                                                    p = `Lam
                                                                    then
                                                                    [tseq]
                                                                    else [])
                                                                    @
                                                                    ((if
                                                                    p = `Col
                                                                    then
                                                                    [tatm]
                                                                    else [])
                                                                    @ [])))))))))))))))))))))))))
  
let _ =
  Earley.set_grammar var
    (Earley.alternatives
       [Earley.fsequence (Earley.string "(" "(")
          (Earley.fsequence
             (Earley.apply_position
                (fun x  ->
                   fun str  ->
                     fun pos  ->
                       fun str'  ->
                         fun pos'  -> ((locate str pos str' pos'), x))
                loptident)
             (Earley.fsequence (Earley.string ":" ":")
                (Earley.sequence kind (Earley.string ")" ")")
                   (fun k  ->
                      fun _  ->
                        fun _  ->
                          fun id  ->
                            let (_loc_id,id) = id  in
                            fun _  -> ((in_pos _loc_id id), (Some k))))));
       Earley.apply
         (fun id  -> let (_loc_id,id) = id  in ((in_pos _loc_id id), None))
         (Earley.apply_position
            (fun x  ->
               fun str  ->
                 fun pos  ->
                   fun str'  -> fun pos'  -> ((locate str pos str' pos'), x))
            loptident)])
  
let _ =
  Earley.set_grammar let_var
    (Earley.alternatives
       [Earley.fsequence
          (Earley.apply_position
             (fun x  ->
                fun str  ->
                  fun pos  ->
                    fun str'  -> fun pos'  -> ((locate str pos str' pos'), x))
             loptident)
          (Earley.sequence (Earley.string ":" ":") kind
             (fun _  ->
                fun k  ->
                  fun id  ->
                    let (_loc_id,id) = id  in ((in_pos _loc_id id), (Some k))));
       Earley.apply
         (fun id  -> let (_loc_id,id) = id  in ((in_pos _loc_id id), None))
         (Earley.apply_position
            (fun x  ->
               fun str  ->
                 fun pos  ->
                   fun str'  -> fun pos'  -> ((locate str pos str' pos'), x))
            loptident)])
  
let _ =
  Earley.set_grammar term_llet
    (Earley.fsequence_position let_kw
       (Earley.fsequence is_rec
          (Earley.fsequence
             (Earley.option None
                (Earley.apply (fun x  -> Some x)
                   (Earley.fsequence (Earley.char '[' '[')
                      (Earley.sequence int_lit (Earley.char ']' ']')
                         (fun n  -> fun _  -> fun _  -> n)))))
             (Earley.fsequence rpat
                (Earley.fsequence (Earley.string "=" "=")
                   (Earley.fsequence
                      (Earley.apply_position
                         (fun x  ->
                            fun str  ->
                              fun pos  ->
                                fun str'  ->
                                  fun pos'  ->
                                    ((locate str pos str' pos'), x)) term)
                      (Earley.sequence in_kw term
                         (fun _default_0  ->
                            fun u  ->
                              fun t  ->
                                let (_loc_t,t) = t  in
                                fun _  ->
                                  fun pat  ->
                                    fun n  ->
                                      fun r  ->
                                        fun _default_1  ->
                                          fun __loc__start__buf  ->
                                            fun __loc__start__pos  ->
                                              fun __loc__end__buf  ->
                                                fun __loc__end__pos  ->
                                                  let _loc =
                                                    locate __loc__start__buf
                                                      __loc__start__pos
                                                      __loc__end__buf
                                                      __loc__end__pos
                                                     in
                                                  let t =
                                                    if not r
                                                    then
                                                      match pat with
                                                      | Simple (Some
                                                          (_,Some k)) ->
                                                          in_pos _loc_t
                                                            (PCoer (t, k))
                                                      | _ -> t
                                                    else
                                                      (match pat with
                                                       | Simple (Some id) ->
                                                           pfixY id _loc_t n
                                                             t
                                                       | _ -> give_up ())
                                                     in
                                                  in_pos _loc
                                                    (PAppl
                                                       ((apply_rpat "_" pat u),
                                                         t))))))))))
  
let _ =
  Earley.set_grammar ords_kinds
    (Earley.alternatives
       [Earley.sequence (list_sep' lgident ",")
          (Earley.option []
             (Earley.sequence (Earley.string "," ",") (list_sep uident ",")
                (fun _  -> fun _default_0  -> _default_0)))
          (fun os  -> fun ks  -> (os, ks));
       Earley.apply (fun _  -> ([], [])) (Earley.empty ());
       Earley.apply (fun ks  -> ([], ks)) (list_sep' uident ",")])
  
let _ =
  Earley.set_grammar term_mlet
    (Earley.fsequence_position let_kw
       (Earley.fsequence ords_kinds
          (Earley.fsequence such_kw
             (Earley.fsequence that_kw
                (Earley.fsequence loptident
                   (Earley.fsequence (Earley.char ':' ':')
                      (Earley.fsequence kind
                         (Earley.sequence in_kw term
                            (fun _default_0  ->
                               fun u  ->
                                 fun k  ->
                                   fun _  ->
                                     fun id  ->
                                       fun _default_1  ->
                                         fun _default_2  ->
                                           fun ((os,ks) as _default_3)  ->
                                             fun _default_4  ->
                                               fun __loc__start__buf  ->
                                                 fun __loc__start__pos  ->
                                                   fun __loc__end__buf  ->
                                                     fun __loc__end__pos  ->
                                                       let _loc =
                                                         locate
                                                           __loc__start__buf
                                                           __loc__start__pos
                                                           __loc__end__buf
                                                           __loc__end__pos
                                                          in
                                                       in_pos _loc
                                                         (PMLet
                                                            (os, ks, k, id,
                                                              u)))))))))))
  
let _ =
  Earley.set_grammar term_cond
    (Earley.fsequence_position if_kw
       (Earley.fsequence term
          (Earley.fsequence then_kw
             (Earley.fsequence term
                (Earley.sequence else_kw (Earley.greedy term)
                   (fun _default_0  ->
                      fun e  ->
                        fun t  ->
                          fun _default_1  ->
                            fun c  ->
                              fun _default_2  ->
                                fun __loc__start__buf  ->
                                  fun __loc__start__pos  ->
                                    fun __loc__end__buf  ->
                                      fun __loc__end__pos  ->
                                        let _loc =
                                          locate __loc__start__buf
                                            __loc__start__pos __loc__end__buf
                                            __loc__end__pos
                                           in
                                        pcond _loc c t e))))))
  
let _ =
  Earley.set_grammar term_reco
    (Earley.sequence (list_sep field ";")
       (Earley.option None
          (Earley.apply (fun x  -> Some x) (Earley.string ";" ";")))
       (fun _default_0  -> fun _  -> _default_0))
  
let _ =
  Earley.set_grammar term_prod
    (Earley.apply (fun l  -> build_prod l) (glist_sep'' term comma))
  
let _ =
  Earley.set_grammar field
    (Earley.fsequence_position lident
       (Earley.fsequence
          (Earley.greedy
             (Earley.option None
                (Earley.apply (fun x  -> Some x)
                   (Earley.sequence (Earley.string ":" ":") kind
                      (fun _  -> fun _default_0  -> _default_0)))))
          (Earley.sequence (Earley.string "=" "=") (Earley.greedy tapp)
             (fun _  ->
                fun t  ->
                  fun k  ->
                    fun l  ->
                      fun __loc__start__buf  ->
                        fun __loc__start__pos  ->
                          fun __loc__end__buf  ->
                            fun __loc__end__pos  ->
                              let _loc =
                                locate __loc__start__buf __loc__start__pos
                                  __loc__end__buf __loc__end__pos
                                 in
                              (l,
                                (match k with
                                 | None  -> t
                                 | Some k -> in_pos _loc (PCoer (t, k))))))))
  
let _ =
  Earley.set_grammar term_list
    (Earley.alternatives
       [Earley.fsequence_position term
          (Earley.sequence (Earley.string "," ",") term_list
             (fun _  ->
                fun l  ->
                  fun t  ->
                    fun __loc__start__buf  ->
                      fun __loc__start__pos  ->
                        fun __loc__end__buf  ->
                          fun __loc__end__pos  ->
                            let _loc =
                              locate __loc__start__buf __loc__start__pos
                                __loc__end__buf __loc__end__pos
                               in
                            list_cons _loc t l));
       Earley.apply_position
         (fun _  ->
            fun __loc__start__buf  ->
              fun __loc__start__pos  ->
                fun __loc__end__buf  ->
                  fun __loc__end__pos  ->
                    let _loc =
                      locate __loc__start__buf __loc__start__pos
                        __loc__end__buf __loc__end__pos
                       in
                    list_nil _loc) (Earley.empty ())])
  
let _ =
  Earley.set_grammar pats
    (Earley.sequence
       (Earley.option None
          (Earley.apply (fun x  -> Some x) (Earley.string "|" "|")))
       (list_sep case "|") (fun _  -> fun ps  -> ps))
  
let _ =
  Earley.set_grammar fpat
    (Earley.alternatives
       [Earley.fsequence (Earley.string "(" "(")
          (Earley.sequence (glist_sep'' var comma) (Earley.string ")" ")")
             (fun ls  -> fun _  -> fun _  -> Record (build_prod ls)));
       Earley.apply (fun x  -> Simple (Some x)) let_var;
       Earley.fsequence (Earley.string "(" "(")
         (Earley.sequence let_var (Earley.string ")" ")")
            (fun x  -> fun _  -> fun _  -> Simple (Some x)));
       Earley.fsequence (Earley.string "{" "{")
         (Earley.sequence
            (list_sep
               (Earley.fsequence lident
                  (Earley.sequence (Earley.string "=" "=") var
                     (fun _  -> fun x  -> fun l  -> (l, x)))) ";")
            (Earley.string "}" "}")
            (fun ls  -> fun _  -> fun _  -> Record ls))])
  
let _ =
  Earley.set_grammar rpat
    (Earley.alternatives
       [fpat; Earley.apply (fun _  -> Simple None) (Earley.empty ())])
  
let _ =
  Earley.set_grammar pattern
    (Earley.alternatives
       [Earley.fsequence var
          (Earley.sequence (Earley.string "::" "::") var
             (fun _  ->
                fun y  -> fun x  -> ("Cons", (Record [("hd", x); ("tl", y)]))));
       Earley.sequence uident rpat (fun c  -> fun x  -> (c, x));
       Earley.sequence (Earley.string "[" "[") (Earley.string "]" "]")
         (fun _  -> fun _  -> ("Nil", NilPat))])
  
let _ =
  Earley.set_grammar case
    (Earley.fsequence pattern
       (Earley.sequence arrow term
          (fun _default_0  ->
             fun t  -> fun ((c,x) as _default_1)  -> (c, x, t))))
  
let _ =
  Earley.set_grammar default
    (Earley.fsequence (Earley.char '|' '|')
       (Earley.fsequence let_var
          (Earley.sequence arrow term
             (fun _default_0  ->
                fun t  -> fun x  -> fun _  -> ((Simple (Some x)), t)))))
  
let hash =
  let fn buf pos = let (c,_,_) = Input.read buf pos  in ((), (c <> '#'))  in
  let no_hash = test ~name:"no_hash" Charset.full fn  in
  Earley.sequence (Earley.char '#' '#') no_hash
    (fun _  -> fun _default_0  -> _default_0)
  
let tex_simple =
  Earley.apply (fun s  -> s.(0))
    (Earley.regexp ~name:"[^}{@#]+" "\\([^}{@#]+\\)")
  
let tex_name = Earley.declare_grammar "tex_name" 
let tex_name_aux = Earley.declare_grammar "tex_name_aux" 
let _ =
  Earley.set_grammar tex_name
    (Earley.fsequence (Earley.char '{' '{')
       (Earley.sequence
          (Earley.apply List.rev
             (Earley.fixpoint []
                (Earley.apply (fun x  -> fun y  -> x :: y) tex_name_aux)))
          (Earley.char '}' '}')
          (fun l  -> fun _  -> fun _  -> String.concat "" l)))
  
let _ =
  Earley.set_grammar tex_name_aux
    (Earley.alternatives
       [Earley.fsequence (Earley.string "{" "{")
          (Earley.sequence
             (Earley.apply List.rev
                (Earley.fixpoint []
                   (Earley.apply (fun x  -> fun y  -> x :: y) tex_name_aux)))
             (Earley.string "}" "}")
             (fun l  ->
                fun _  -> fun _  -> "{" ^ ((String.concat "" l) ^ "}")));
       tex_simple])
  
let tex_text = Earley.declare_grammar "tex_text" 
let latex_atom = Earley.declare_grammar "latex_atom" 
let sub = Earley.declare_grammar "sub" 
let _ =
  Earley.set_grammar tex_text
    (Earley.fsequence (Earley.string "{" "{")
       (Earley.sequence
          (Earley.apply List.rev
             (Earley.fixpoint []
                (Earley.apply (fun x  -> fun y  -> x :: y) latex_atom)))
          (Earley.string "}" "}")
          (fun l  -> fun _  -> fun _  -> Latex.List l)))
  
let _ =
  Earley.set_grammar latex_atom
    (Earley.alternatives
       [Earley.fsequence hash
          (Earley.fsequence (Earley.string "?" "?")
             (Earley.fsequence
                (Earley.apply_position
                   (fun x  ->
                      fun str  ->
                        fun pos  ->
                          fun str'  ->
                            fun pos'  -> ((locate str pos str' pos'), x))
                   lident)
                (Earley.fsequence (Earley.string "." ".")
                   (Earley.fsequence
                      (Earley.apply_position
                         (fun x  ->
                            fun str  ->
                              fun pos  ->
                                fun str'  ->
                                  fun pos'  ->
                                    ((locate str pos str' pos'), x)) lident)
                      (Earley.fsequence
                         (Earley.option 0
                            (Earley.sequence (Earley.string "." ".") int_lit
                               (fun _  -> fun _default_0  -> _default_0)))
                         (Earley.sequence
                            (Earley.option "\206\177"
                               (Earley.sequence (Earley.string "~" "~")
                                  lgident
                                  (fun _  -> fun _default_0  -> _default_0)))
                            (Earley.string "#" "#")
                            (fun ordname  ->
                               fun _  ->
                                 fun i  ->
                                   fun name  ->
                                     let (_loc_name,name) = name  in
                                     fun _  ->
                                       fun id  ->
                                         let (_loc_id,id) = id  in
                                         fun _  ->
                                           fun _default_0  ->
                                             let prf =
                                               try
                                                 (Hashtbl.find val_env id).proof
                                               with
                                               | Not_found  ->
                                                   raise
                                                     (Unbound
                                                        (id, (Some _loc_id)))
                                                in
                                             let schemas =
                                               try
                                                 Latex.search_schemas name
                                                   prf
                                               with
                                               | Not_found  ->
                                                   raise
                                                     (Unbound
                                                        (name,
                                                          (Some _loc_name)))
                                                in
                                             Latex.Sch
                                               ((List.nth schemas i),
                                                 ordname))))))));
       Earley.fsequence hash
         (Earley.sequence (Earley.string "witnesses" "witnesses")
            (Earley.string "#" "#")
            (fun _  -> fun _  -> fun _default_0  -> Latex.Witnesses));
       Earley.fsequence hash
         (Earley.fsequence (Earley.option 0 int_lit)
            (Earley.fsequence
               (Earley.option None
                  (Earley.apply (fun x  -> Some x) (Earley.string "!" "!")))
               (Earley.sequence (change_layout kind subml_blank)
                  (Earley.string "#" "#")
                  (fun k  ->
                     fun _  ->
                       fun u  ->
                         fun br  ->
                           fun _default_0  ->
                             Latex.Kind
                               (br, (u <> None),
                                 (unbox (unsugar_kind empty_env k)))))));
       Earley.fsequence (Earley.string "@" "@")
         (Earley.fsequence (Earley.option 0 int_lit)
            (Earley.fsequence
               (Earley.option None
                  (Earley.apply (fun x  -> Some x) (Earley.string "!" "!")))
               (Earley.sequence (change_layout term subml_blank)
                  (Earley.string "@" "@")
                  (fun t  ->
                     fun _  ->
                       fun u  ->
                         fun br  ->
                           fun _  ->
                             Latex.Term
                               (br, (u <> None),
                                 (unbox (unsugar_term empty_env t)))))));
       Earley.apply (fun t  -> Latex.Text t) (Earley.greedy tex_simple);
       tex_text;
       Earley.fsequence hash
         (Earley.fsequence (Earley.string "check" "check")
            (Earley.sequence sub (Earley.string "#" "#")
               (fun ((a,b) as _default_0)  ->
                  fun _  ->
                    fun _  ->
                      fun _default_1  ->
                        let a = unbox (unsugar_kind empty_env a)  in
                        let b = unbox (unsugar_kind empty_env b)  in
                        let (prf,cg) = subtype None a b  in
                        Latex.SProof (prf, cg))));
       Earley.fsequence hash
         (Earley.fsequence (Earley.option 0 int_lit)
            (Earley.fsequence (Earley.string ":" ":")
               (Earley.sequence
                  (Earley.apply_position
                     (fun x  ->
                        fun str  ->
                          fun pos  ->
                            fun str'  ->
                              fun pos'  -> ((locate str pos str' pos'), x))
                     lident) (Earley.string "#" "#")
                  (fun id  ->
                     let (_loc_id,id) = id  in
                     fun _  ->
                       fun _  ->
                         fun br  ->
                           fun _default_0  ->
                             try
                               Latex.Kind
                                 (br, false,
                                   ((Hashtbl.find val_env id).ttype))
                             with
                             | Not_found  ->
                                 raise (Unbound (id, (Some _loc_id)))))));
       Earley.fsequence hash
         (Earley.fsequence (Earley.option 0 int_lit)
            (Earley.fsequence (Earley.string "?" "?")
               (Earley.sequence
                  (Earley.apply_position
                     (fun x  ->
                        fun str  ->
                          fun pos  ->
                            fun str'  ->
                              fun pos'  -> ((locate str pos str' pos'), x))
                     uident) (Earley.string "#" "#")
                  (fun id  ->
                     let (_loc_id,id) = id  in
                     fun _  ->
                       fun _  ->
                         fun br  ->
                           fun _default_0  ->
                             try
                               Latex.KindDef (br, (Hashtbl.find typ_env id))
                             with
                             | Not_found  ->
                                 raise (Unbound (id, (Some _loc_id)))))));
       Earley.fsequence (Earley.string "##" "##")
         (Earley.sequence
            (Earley.apply_position
               (fun x  ->
                  fun str  ->
                    fun pos  ->
                      fun str'  ->
                        fun pos'  -> ((locate str pos str' pos'), x)) lident)
            (Earley.string "#" "#")
            (fun id  ->
               let (_loc_id,id) = id  in
               fun _  ->
                 fun _  ->
                   try Latex.TProof ((Hashtbl.find val_env id).proof)
                   with | Not_found  -> raise (Unbound (id, (Some _loc_id)))));
       Earley.fsequence hash
         (Earley.fsequence (Earley.string "!" "!")
            (Earley.sequence
               (Earley.apply_position
                  (fun x  ->
                     fun str  ->
                       fun pos  ->
                         fun str'  ->
                           fun pos'  -> ((locate str pos str' pos'), x))
                  lident) (Earley.string "#" "#")
               (fun id  ->
                  let (_loc_id,id) = id  in
                  fun _  ->
                    fun _  ->
                      fun _default_0  ->
                        try Latex.Sct ((Hashtbl.find val_env id).calls_graph)
                        with
                        | Not_found  -> raise (Unbound (id, (Some _loc_id))))))])
  
let _ =
  Earley.set_grammar sub
    (change_layout
       (Earley.fsequence kind
          (Earley.sequence subset kind (fun _  -> fun b  -> fun a  -> (a, b))))
       subml_blank)
  
let tex_name = change_layout tex_name no_blank 
let tex_text = change_layout tex_text no_blank 
type name = (string option * string)
let new_type =
  (fun (tex,name)  ->
     fun (oargs,kargs)  ->
       fun k  ->
         let tdef_tex_name =
           match tex with | None  -> "\\mathrm{" ^ (name ^ "}") | Some s -> s
            in
         let oarg_names = Array.of_list oargs  in
         let karg_names = Array.of_list kargs  in
         let tdef_oarity = Array.length oarg_names  in
         let tdef_karity = Array.length karg_names  in
         let tdef_ovariance = Array.make tdef_oarity Non  in
         let tdef_kvariance = Array.make tdef_karity Non  in
         let fn oargs =
           let gn kargs =
             let kinds = ref []  in
             let f i k =
               let v = (k, (Reg (i, tdef_kvariance)))  in
               kinds := (((karg_names.(i)), v) :: (!kinds))  in
             Array.iteri f kargs;
             (let ordis = ref []  in
              let f i o =
                let v = (o, (Reg (i, tdef_ovariance)))  in
                ordis := (((oarg_names.(i)), v) :: (!ordis))  in
              Array.iteri f oargs;
              unsugar_kind
                { empty_env with kinds = (!kinds); ordinals = (!ordis) } k)
              in
           mbind mk_free_k karg_names gn  in
         let b = mbind mk_free_o oarg_names fn  in
         let tdef_value = unbox b  in
         let td =
           {
             tdef_name = name;
             tdef_tex_name;
             tdef_karity;
             tdef_oarity;
             tdef_value;
             tdef_kvariance;
             tdef_ovariance
           }  in
         if !verbose then Io.out "%a\n%!" (print_kind_def false) td;
         Hashtbl.add typ_env name td : name ->
                                         (string list * string list) ->
                                           pkind -> unit)
  
type flag =
  | MustPass 
  | MustFail 
  | CanFail 
exception OK 
let check pos flag f a =
  let res =
    try f a
    with
    | Error.Error l as e ->
        (match flag with
         | MustPass  -> raise e
         | MustFail |CanFail  -> raise OK)
    | Loop_error p as e ->
        (match flag with
         | MustPass  -> raise e
         | MustFail |CanFail  -> raise OK)
    | Sys.Break  as e -> raise e
    | e ->
        (Printexc.print_backtrace stderr;
         Io.err "UNCAUGHT EXCEPTION: %s\n%!" (Printexc.to_string e);
         exit 1)
     in
  if flag = CanFail
  then Io.out "A NEW TEST PASSED at %a.\n%!" print_position pos;
  if flag = MustFail
  then (Io.err "A WRONG TEST PASSED at %a\n%!" print_position pos; exit 1);
  res 
let new_val =
  (fun fg  ->
     fun nm  ->
       fun k  ->
         fun t  ->
           let (tex_name,name) = nm  in
           let tex_name = from_opt tex_name ("\\mathrm{" ^ (name ^ "}"))  in
           let t = unbox (unsugar_term empty_env t)  in
           let k = map_opt (fun k  -> unbox (unsugar_kind empty_env k)) k  in
           try
             let (k,proof,calls_graph) = check t.pos fg (type_check t) k  in
             if !verbose
             then Io.out "val %s : %a\n%!" name (print_kind false) k;
             Hashtbl.add val_env name
               {
                 name;
                 tex_name;
                 value = (eval t);
                 orig_value = t;
                 ttype = k;
                 proof;
                 calls_graph
               }
           with | OK  -> () : flag -> name -> pkind option -> pterm -> unit)
  
let check_sub =
  (fun pos  ->
     fun flag  ->
       fun a  ->
         fun b  ->
           let a = unbox (unsugar_kind empty_env a)  in
           let b = unbox (unsugar_kind empty_env b)  in
           (try ignore (check pos flag (subtype None a) b) with | OK  -> ());
           reset_epsilon_tbls () : popt -> flag -> pkind -> pkind -> unit)
  
let eval_term =
  (fun t  ->
     let t = unbox (unsugar_term empty_env t)  in
     let (k,_,_) = type_check t None  in
     let t = eval t  in
     Io.out "%a : %a\n%!" (print_term true) t (print_kind false) k : 
  pterm -> unit) 
let read_file = (ref (fun _  -> assert false) : (string -> unit) ref) 
let include_file =
  (fun fn  ->
     let open Latex in
       let s_ignore_latex = !ignore_latex  in
       ignore_latex := true;
       (let s_verbose = !Ast.verbose  in
        Ast.verbose := false;
        (try
           (!read_file) fn;
           ignore_latex := s_ignore_latex;
           Ast.verbose := s_verbose
         with
         | e ->
             (ignore_latex := s_ignore_latex;
              Ast.verbose := s_verbose;
              raise e))) : string -> unit)
  
let output_graphml =
  (fun id  ->
     try
       let prf = (Hashtbl.find val_env id.elt).proof  in
       Graph.output (let open Io in fmts.gml) prf
     with | Not_found  -> unbound id : strloc -> unit)
  
let flag = Earley.declare_grammar "flag" 
let _ =
  Earley.set_grammar flag
    (Earley.alternatives
       [Earley.apply (fun _  -> CanFail) (Earley.char '?' '?');
       Earley.apply (fun _  -> MustPass) (Earley.empty ());
       Earley.apply (fun _  -> MustFail) (Earley.char '!' '!')])
  
let (command,command__set__grammar) = Earley.grammar_family "command" 
let kind_def = Earley.declare_grammar "kind_def" 
let kind_def_args = Earley.declare_grammar "kind_def_args" 
let val_def = Earley.declare_grammar "val_def" 
let _ =
  command__set__grammar
    (fun top  ->
       Earley.alternatives
         ((if top
           then
             [Earley.apply (fun _default_0  -> raise End_of_file)
                (Earley.alternatives [exit_kw; quit_kw])]
           else []) @
            ((Earley.sequence type_kw (Earley.greedy kind_def)
                (fun _default_1  ->
                   fun ((tn,n,args,k) as _default_0)  ->
                     new_type (tn, n) args k))
            ::
            (Earley.sequence eval_kw (Earley.greedy term)
               (fun _default_0  -> fun t  -> eval_term t))
            ::
            (Earley.fsequence flag
               (Earley.sequence val_kw (Earley.greedy val_def)
                  (fun _default_1  ->
                     fun ((n,k,t) as _default_0)  ->
                       fun f  -> new_val f n k t)))
            ::
            (Earley.fsequence_position flag
               (Earley.fsequence check_kw
                  (Earley.fsequence (Earley.greedy kind)
                     (Earley.sequence subset (Earley.greedy kind)
                        (fun _  ->
                           fun b  ->
                             fun a  ->
                               fun _default_0  ->
                                 fun f  ->
                                   fun __loc__start__buf  ->
                                     fun __loc__start__pos  ->
                                       fun __loc__end__buf  ->
                                         fun __loc__end__pos  ->
                                           let _loc =
                                             locate __loc__start__buf
                                               __loc__start__pos
                                               __loc__end__buf
                                               __loc__end__pos
                                              in
                                           check_sub (Some _loc) f a b)))))
            ::
            (Earley.sequence include_kw (Earley.greedy str_lit)
               (fun _  -> fun fn  -> include_file fn))
            ::
            (Earley.sequence graphml_kw (Earley.greedy llident)
               (fun _  -> fun id  -> output_graphml id))
            ::
            ((if not top
              then
                [Earley.sequence latex_kw (Earley.greedy tex_text)
                   (fun _default_0  -> fun t  -> Io.tex "%a%!" Latex.output t)]
              else []) @
               ((Earley.fsequence set_kw
                   (Earley.sequence (Earley.string "verbose" "verbose")
                      enables (fun _  -> fun b  -> fun _  -> verbose := b)))
               ::
               ((if not top
                 then
                   [Earley.fsequence set_kw
                      (Earley.sequence (Earley.string "texfile" "texfile")
                         str_lit
                         (fun _  -> fun fn  -> fun _  -> Io.set_tex_file fn))]
                 else []) @
                  ((if not top
                    then
                      [Earley.fsequence set_kw
                         (Earley.sequence (Earley.string "gmlfile" "gmlfile")
                            str_lit
                            (fun _  ->
                               fun fn  -> fun _  -> Io.set_gml_file fn))]
                    else []) @
                     ((if top
                       then
                         [Earley.apply (fun _  -> LibTools.clear ()) clear_kw]
                       else []) @ []))))))))
  
let _ =
  Earley.set_grammar kind_def
    (Earley.fsequence
       (Earley.option None (Earley.apply (fun x  -> Some x) tex_name))
       (Earley.fsequence uident
          (Earley.fsequence kind_def_args
             (Earley.sequence (Earley.string "=" "=") kind
                (fun _  ->
                   fun _default_0  ->
                     fun _default_1  ->
                       fun _default_2  ->
                         fun _default_3  ->
                           (_default_3, _default_2, _default_1, _default_0))))))
  
let _ =
  Earley.set_grammar kind_def_args
    (Earley.alternatives
       [Earley.fsequence (Earley.string "(" "(")
          (Earley.fsequence (list_sep' lgident ",")
             (Earley.sequence
                (Earley.option []
                   (Earley.sequence (Earley.string "," ",")
                      (list_sep uident ",")
                      (fun _  -> fun _default_0  -> _default_0)))
                (Earley.string ")" ")")
                (fun ks  -> fun _  -> fun os  -> fun _  -> (os, ks))));
       Earley.apply (fun _  -> ([], [])) (Earley.empty ());
       Earley.fsequence (Earley.string "(" "(")
         (Earley.sequence (list_sep' uident ",") (Earley.string ")" ")")
            (fun ks  -> fun _  -> fun _  -> ([], ks)))])
  
let _ =
  Earley.set_grammar val_def
    (Earley.fsequence is_rec
       (Earley.fsequence
          (Earley.option None
             (Earley.apply (fun x  -> Some x)
                (Earley.fsequence (Earley.char '[' '[')
                   (Earley.sequence int_lit (Earley.char ']' ']')
                      (fun _default_0  -> fun _  -> fun _  -> _default_0)))))
          (Earley.fsequence
             (Earley.option None (Earley.apply (fun x  -> Some x) tex_name))
             (Earley.fsequence
                (Earley.apply_position
                   (fun x  ->
                      fun str  ->
                        fun pos  ->
                          fun str'  ->
                            fun pos'  -> ((locate str pos str' pos'), x))
                   lident)
                (Earley.fsequence
                   (Earley.option None
                      (Earley.apply (fun x  -> Some x)
                         (Earley.sequence (Earley.string ":" ":") kind
                            (fun _  -> fun _default_0  -> _default_0))))
                   (Earley.sequence (Earley.string "=" "=")
                      (Earley.apply_position
                         (fun x  ->
                            fun str  ->
                              fun pos  ->
                                fun str'  ->
                                  fun pos'  ->
                                    ((locate str pos str' pos'), x)) term)
                      (fun _  ->
                         fun t  ->
                           let (_loc_t,t) = t  in
                           fun k  ->
                             fun id  ->
                               let (_loc_id,id) = id  in
                               fun tex  ->
                                 fun n  ->
                                   fun r  ->
                                     let t =
                                       if not r
                                       then t
                                       else
                                         pfixY ((in_pos _loc_id id), None)
                                           _loc_t n t
                                        in
                                     ((tex, id), k, t))))))))
  
let toplevel_of_string =
  (parse_string (command true) subml_blank : string -> unit) 
let full_of_string =
  (fun filename  ->
     parse_string ~filename
       (Earley.apply (fun _  -> ())
          (Earley.apply List.rev
             (Earley.fixpoint []
                (Earley.apply (fun x  -> fun y  -> x :: y) (command false)))))
       subml_blank : string -> string -> unit)
  
let full_of_buffer =
  (parse_buffer
     (Earley.apply (fun _  -> ())
        (Earley.apply List.rev
           (Earley.fixpoint []
              (Earley.apply (fun x  -> fun y  -> x :: y) (command false)))))
     subml_blank : Input.buffer -> unit)
  
let eval_file =
  let eval_file fn =
    let buf = Io.file fn  in
    if !verbose then Io.out "## loading file %S\n%!" fn;
    parse_buffer
      (Earley.apply (fun _  -> ())
         (Earley.apply List.rev
            (Earley.fixpoint []
               (Earley.apply (fun x  -> fun y  -> x :: y) (command false)))))
      subml_blank buf
     in
  read_file := eval_file; eval_file 
let handle_exception =
  (fun fn  ->
     fun v  ->
       let pp = print_position  in
       let ok = ref false  in
       (try fn v; ok := true
        with | End_of_file  -> raise End_of_file
        | Sys.Break  -> Io.err "\n[Interrupted]\n%!"
        | Arity_error (p,m) -> Io.err "%a: %s\n%!" pp p m
        | Positivity_error (p,m) -> Io.err "%a: %s\n%!" pp p m
        | Parse_error (buf,pos) ->
            Io.err "%a: syntax error.\n%!" pp
              (Some (Pos.locate buf pos buf (pos + 1)))
        | Unclosed (b,p) ->
            Io.err "%a: unclosed %scomment.\n%!" pp p
              (if b then "string in a " else "")
        | Unbound (s,p) -> Io.err "%a: unbound variable %s.\n%!" pp p s
        | Error.Error l -> Io.err "%a: error:\n%!" Error.display_errors l
        | Loop_error p -> Io.err "%a: loops...\n%!" pp p);
       !ok : ('a -> 'b) -> 'a -> bool)
  
